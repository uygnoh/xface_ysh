#ifndef __CONFIG_H__
#define __CONFIG_H__

#include <mcs51/8051.h>

#define DS1302_SCK     P1_0
#define DS1302_SDA     P1_1
#define DS1302_RST     P1_2

#endif // __CONFIG_H__
