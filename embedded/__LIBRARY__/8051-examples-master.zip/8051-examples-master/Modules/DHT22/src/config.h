#ifndef __CONFIG_H__
#define __CONFIG_H__

#include <mcs51/8051.h>

#define DHT22_PIN   P0_0

#endif // __CONFIG_H__
