#ifndef __CONFIG_H__
#define __CONFIG_H__

#include <mcs51/8051.h>

#define HC_SR04_ECHO      P2_1
#define HC_SR04_TRIGGER   P2_0

#endif // __CONFIG_H__
