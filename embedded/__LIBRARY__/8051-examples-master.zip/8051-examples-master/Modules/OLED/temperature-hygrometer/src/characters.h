#ifndef __CHARACTERS_H__
#define __CHARACTERS_H__

#include <stdint.h>

extern const uint8_t __code CHARACTERS_8X16[][16];

#endif // __CHARACTERS_H__
