#ifndef __SPI_H__
#define __SPI_H__

#include "config.h"

void spi_read_write(unsigned char data);

#endif
