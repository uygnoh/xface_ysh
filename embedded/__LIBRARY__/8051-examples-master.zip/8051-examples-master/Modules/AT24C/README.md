AT24Cxx
====

AT24Cxx是串行CMOS E2PROM

![](./AT24C.jpg)