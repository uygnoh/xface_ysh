#ifndef __SERIAL_H__
#define __SERIAL_H__

#include <mcs51/8051.h>

void serial_init(void);

#endif // __SERIAL_H__
