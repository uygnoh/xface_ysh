#ifndef __CONFIG_H__
#define __CONFIG_H__

#include <mcs51/8051.h>

#define DS18B20_PIN   P0_0

#endif // __CONFIG_H__
