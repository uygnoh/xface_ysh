#ifndef __CONFIG_H__
#define __CONFIG_H__

#include <mcs51/8051.h>

#define IR_NEC_PIN      P3_2

#endif // __CONFIG_H__
