#ifndef __delay_h__
#define __delay_h__

void delay(unsigned int t);

#endif
