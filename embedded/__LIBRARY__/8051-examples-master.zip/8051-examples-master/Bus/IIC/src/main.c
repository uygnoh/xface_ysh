#include <mcs51/8051.h>
#include "iic.h"

void main()
{

  while(1)
  {

  }
}
