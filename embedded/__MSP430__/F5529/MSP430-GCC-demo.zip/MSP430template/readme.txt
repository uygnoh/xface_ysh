#MSP430F5529工程模板
*编译：终端1：make
*清除编译：终端1：make clean
*下载：终端2：./Tools/gdb_agent_console ./Tools/msp430.dat
       终端3：make debug
          |连接agent：target remote :55000
          |下载程序：load

*gdb中输入continue或按复位键可执行程序        
