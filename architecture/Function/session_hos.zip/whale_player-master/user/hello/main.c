#include <stdio.h>

int main(int argc, char *argv[])
{
	printf("\n\n##########################################\n");
	printf("##\t\t\t\t\t##\n");
	printf("##\t\tHello World !\t\t##\n");
	printf("##\t\t\t\t\t##\n");
	printf("##########################################\n\n\n");

	return 0;
}
