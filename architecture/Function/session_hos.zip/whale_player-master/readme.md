配套哔哩哔哩视频主页：[才鲸嵌入式](https://space.bilibili.com/106424039) <br>

----
# 1. Get the 'menuconfig' source code of linux  
Get scripts folder(for make menuconfig function) of linux kernel stable source code v5.10.12 on 20210130.  
[linux-5.10.12](https://cdn.kernel.org/pub/linux/kernel/v5.x/linux-5.10.12.tar.xz)  
[网易开源镜像站](http://mirrors.163.com/kernel/v5.x/linux-5.10.12.tar.gz)  
----
# 2. Modify scripts folder of linux  
Modify Kbuild and Kconfig  
name@pc:~$ make menuconfig
----
# 3. Add user codes  
make menuconfig
make
----
# 4. Run application
./

